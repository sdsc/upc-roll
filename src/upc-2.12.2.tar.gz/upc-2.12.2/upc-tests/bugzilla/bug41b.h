/* C mode file */

int b = 20;
