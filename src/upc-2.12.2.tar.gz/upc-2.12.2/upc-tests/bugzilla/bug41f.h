#include <memory.h>

int j = 100;
shared int f = 60;
