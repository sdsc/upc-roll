  int c;

  b = 3;
  c = 4;
  a = b + c;
