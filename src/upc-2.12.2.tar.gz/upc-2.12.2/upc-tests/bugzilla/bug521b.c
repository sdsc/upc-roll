#include <bug521b2.h>

#include <bug521b.h>

int main() {
  return 0;
}
