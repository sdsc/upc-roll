  shared [']'] int x[44];
