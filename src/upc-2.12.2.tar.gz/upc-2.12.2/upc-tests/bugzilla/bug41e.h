/* C mode header */

#include <string.h>

int e = 50;
