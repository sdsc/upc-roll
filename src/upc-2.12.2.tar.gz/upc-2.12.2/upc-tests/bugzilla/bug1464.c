int main(void)
{
    int i;
    int *p[1] = { &i };
    return 0;
}
