/* Test for regression on a lexxer problem w/ whitespace following ] */
static shared [1000] int * x;
