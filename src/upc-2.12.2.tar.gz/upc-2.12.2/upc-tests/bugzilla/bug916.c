#include <bug916.h>
#include <stdio.h>

int main() 
{
    printf("SUCCESS\n");
    return 0;
}
