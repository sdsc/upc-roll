  int i;
  float f;
