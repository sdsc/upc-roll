#pragma shared [] int x[24];
#pragma upc c_code
