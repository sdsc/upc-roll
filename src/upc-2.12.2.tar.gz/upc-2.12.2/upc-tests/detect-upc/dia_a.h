#include <dia_shared.h>

typedef int a_type;

