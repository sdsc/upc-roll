#include <dia_shared.h>


typedef float b_type;
