#ifndef _B_H
#define _B_H
# include <nest_a.h>
extern float b;
#endif
