#include <dia_shared.h>
#include <dia_a.h>
#include <dia_b.h>
#include <stdio.h>

int main ()
{
    blar = 4;
    printf("SUCCESS\n");
    return 0;
}
