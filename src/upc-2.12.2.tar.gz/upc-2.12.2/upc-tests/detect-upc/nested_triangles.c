#include <nest_shared.h>
#include <nest_a.h>
#include <nest_b.h>
#include <nest_c.h>
#include <stdio.h>

int main () 
{ 
    printf ("SUCCESS\n");
    return 0; 
}

