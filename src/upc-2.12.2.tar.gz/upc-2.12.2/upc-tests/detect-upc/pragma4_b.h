/* This file should fail to preprocess due to UPC code under C header */
#pragma upc upc_code
