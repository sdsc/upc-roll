#ifndef _SHARED_H
#define _SHARED_H
#include <cyc_a.h>
#include <upc.h>
extern shared int blar;
#endif
