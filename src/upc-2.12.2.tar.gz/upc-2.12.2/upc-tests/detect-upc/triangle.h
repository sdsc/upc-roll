#ifndef BUG521_H
#define BUG521_H

int hub521h_beforeupcrelaxed;

#include <upc_relaxed.h>

int bug521h_afterupcrelaxed;

#endif
