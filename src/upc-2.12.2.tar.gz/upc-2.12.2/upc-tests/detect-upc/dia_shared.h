#ifndef _SHARE_H
#define _SHARE_H
shared int blar;
#endif

