#include <cyc_a.h>
#include <stdio.h>

int main ()
{
    printf("SUCCESS\n");
    return 0;
}

