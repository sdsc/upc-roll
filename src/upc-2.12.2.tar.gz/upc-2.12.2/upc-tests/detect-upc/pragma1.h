/* This file should fail to preprocess due to conflicting pragmas */
#pragma upc upc_code
#pragma upc c_code
