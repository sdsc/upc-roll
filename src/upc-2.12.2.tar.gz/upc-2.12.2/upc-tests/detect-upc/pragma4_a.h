/* This file should fail to preprocess due to UPC code under C header */
#pragma upc c_code
#include <pragma4_b.h>
