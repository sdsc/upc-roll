#ifndef _A_H
#define _A_H
# include <nest_shared.h>

int a;
#endif

