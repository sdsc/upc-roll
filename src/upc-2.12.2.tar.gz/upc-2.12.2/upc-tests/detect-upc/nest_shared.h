#ifndef _SHARE_H
#define _SHARE_H
extern shared int shar;
#endif

