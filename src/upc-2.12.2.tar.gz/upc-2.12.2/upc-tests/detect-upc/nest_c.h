#ifndef _B_H
#define _B_H
# include <nest_b.h>
extern int c;
#endif
