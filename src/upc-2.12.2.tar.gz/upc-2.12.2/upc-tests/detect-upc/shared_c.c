#include <upc.h>
#include <shared_c.h>
#include <stdio.h>

int main(void) {
    printf("SUCCESS\n");
    return 0;
}
