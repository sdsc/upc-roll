/*   $Source: /var/local/cvs/gasnet/other/testspawn/gasnet_core_internal.h,v $
 *     $Date: 2005/02/17 13:19:11 $
 * $Revision: 1.2 $
 * Description: 
 * Copyright 2005, Regents of the University of California
 * Terms of use are as specified in license.txt
 */

#ifndef _GASNET_CORE_INTERNAL_H
#define _GASNET_CORE_INTERNAL_H

#include <gasnet_internal.h>
#include <gasnet_bootstrap_internal.h>

#endif
