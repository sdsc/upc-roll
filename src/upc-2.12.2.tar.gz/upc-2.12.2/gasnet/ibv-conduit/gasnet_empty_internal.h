/* This is an empty file to satisfy the "$(srcdir)/*.[ch]" in libgasnet_dependencies.
 * The actual sources reside in the vapi-conduit directory.
 */
#error "nothing should #include this file"

