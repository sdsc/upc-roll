/*   $Source: /var/local/cvs/gasnet/tests/testtoolscxx.cc,v $
 *     $Date: 2006/08/02 23:10:50 $
 * $Revision: 1.1 $
 * Description: General GASNet correctness tests in C++
 * Copyright 2002, Dan Bonachea <bonachea@cs.berkeley.edu>
 * Terms of use are as specified in license.txt
 */

#include "testtools.c"
