#define ALL_COLL_ENABLED 0
#define ALL_ADDR_MODE_ENABLED 0

#define BROADCAST_ENABLED 1
#define MULTI_SINGLE_MODE_ENABLED 1

#include "testcollperf.c"
